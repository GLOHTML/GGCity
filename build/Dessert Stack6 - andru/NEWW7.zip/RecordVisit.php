<?php
	$dir = str_replace(basename($_SERVER["SCRIPT_FILENAME"]),"",$_SERVER["SCRIPT_NAME"]);
	include_once($_SERVER['DOCUMENT_ROOT']."/includegl1/RecordVisit.php");
?>